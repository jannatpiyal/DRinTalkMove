import json
import torch
from transformers import BertTokenizer, BertForSequenceClassification
from torch.utils.data import DataLoader, Dataset

# Example custom dataset for testing
class RelationDataset(Dataset):
    def __init__(self, pairs, labels, tokenizer, max_length):
        self.pairs = pairs
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, idx):
        text_pair = self.pairs[idx]
        label = self.labels[idx]

        # Tokenize the text pairs
        encoding = self.tokenizer(
            text_pair[0],
            text_pair[1],
            max_length=self.max_length,
            padding="max_length",
            truncation=True,
            return_tensors="pt",
        )

        return {
            "input_ids": encoding["input_ids"].squeeze(0),
            "attention_mask": encoding["attention_mask"].squeeze(0),
            "label": torch.tensor(label, dtype=torch.long),
        }

# Data preparation function
def prepare_data(data, relation_type="Question-answer_pair"):
    positive_samples = []
    negative_samples = []

    for item in data:
        edus = item["edus"]
        relations = item["relations"]

        for relation in relations:
            x_idx = int(relation["x"].split("_")[0])
            y_idx = int(relation["y"].split("_")[0])
            if x_idx == -1 or y_idx == -1:
                continue
            rel_type = relation["type"]

            text_x = edus[x_idx]["text"]
            text_y = edus[y_idx]["text"]

            if rel_type == relation_type:
                positive_samples.append((text_x, text_y))
            else:
                negative_samples.append((text_x, text_y))

    pairs = positive_samples + negative_samples
    labels = [1] * len(positive_samples) + [0] * len(negative_samples)

    return pairs, labels

# Remove Question-answer relations based on predictions
def remove_question_answer_relations(data, predictions, relation_type="Question-answer_pair"):
    prediction_index = 0  # Tracks the index in the predictions list
    updated_data = []

    for item in data:
        edus = item["edus"]
        updated_relations = []

        for relation in item["relations"]:
            if relation["type"] == relation_type:
                # Check the prediction for this relation
                if predictions[prediction_index] == 1:  # Keep the relation if the prediction is "yes"
                    updated_relations.append(relation)
                # Increment prediction index as this relation was checked
                prediction_index += 1
            else:
                # Keep all non-Question-answer relations
                updated_relations.append(relation)

        # Update the item's relations with the filtered list
        item["relations"] = updated_relations
        updated_data.append(item)

    return updated_data



if __name__ == "__main__":

    # Load test data: all talkmoves splits
    #file_names = ['train','dev','test']
    file_name = 'train'

    
    with open(f'/home/jana7431/RGCN/dataJSON/updated_converted_{file_name}_predictions2.json', 'r') as f:
         json_data = json.load(f)
                

    # Extract pairs and labels
    test_pairs, test_labels = prepare_data(json_data)

    # Load pretrained model and tokenizer
    model_path = "/mnt/datastore/jana7431/CorrectionModule/models/bert_relation_classifier"
    tokenizer = BertTokenizer.from_pretrained(model_path)
    model = BertForSequenceClassification.from_pretrained(model_path)

    # Prepare test dataset and dataloader
    max_length = 128
    batch_size = 16
    test_dataset = RelationDataset(test_pairs, test_labels, tokenizer, max_length)
    test_loader = DataLoader(test_dataset, batch_size=batch_size)

    # Set device and move model to device
    device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")
    model.to(device)

    # Evaluate on test data
    model.eval()
    correct = 0
    total = 0
    all_predictions = []
    with torch.no_grad():
        for batch in test_loader:
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            labels = batch["label"].to(device)

            outputs = model(input_ids=input_ids, attention_mask=attention_mask)
            predictions = torch.argmax(outputs.logits, dim=-1)

            correct += (predictions == labels).sum().item()
            total += labels.size(0)
            all_predictions.extend(predictions.cpu().tolist())

    # Calculate and print accuracy
    accuracy = correct / total
    print(f"Test Accuracy: {accuracy:.4f}")

    # After predictions are generated
    updated_data = remove_question_answer_relations(json_data, all_predictions)

    # Save the updated data to a new JSON file
    with open(f"/home/jana7431/RGCN/dataJSON/QAupdated_{file_name}_predictions.json", "w") as f:
        json.dump(updated_data, f, indent=4)

    print(f"Updated test data saved")

    