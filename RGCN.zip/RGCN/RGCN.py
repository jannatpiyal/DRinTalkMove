import argparse
import os
import json
import time
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import FastRGCNConv, RGCNConv
from torch_geometric.utils import k_hop_subgraph
from sklearn.metrics import classification_report
import pandas as pd
import numpy as np
from torch_geometric.loader import NeighborLoader



class Net(torch.nn.Module):
    def __init__(self, x, num_features, num_relations, num_classes):
        super().__init__()
        #Conv = FastRGCNConv
        self.x = x
        Conv = RGCNConv
        self.conv1 = Conv(num_features, 16, num_relations, num_bases=30)
        self.conv2 = Conv(16, num_classes, num_relations, num_bases=30)

    def forward(self, edge_index, edge_type):
        x = F.relu(self.conv1(self.x, edge_index, edge_type))
        x = self.conv2(x, edge_index, edge_type)
        return F.log_softmax(x, dim=1)

def train(model,data,optimizer):
    model.train()
    optimizer.zero_grad()
    out = model(data.edge_index, data.edge_type)
    loss = F.nll_loss(out[data.train_idx], data.train_y)
    loss.backward(retain_graph=True)
    optimizer.step()
    return float(loss)


@torch.no_grad()
def test(model,data):
    model.eval()
    pred = model(data.edge_index, data.edge_type).argmax(dim=-1)
    train_acc = float((pred[data.train_idx] == data.train_y).float().mean())
    test_acc = float((pred[data.test_idx] == data.test_y).float().mean())

    # Get the ground truth and predicted labels for classification report
    true_labels = data.test_y.cpu().numpy()
    predicted_labels = pred[data.test_idx].cpu().numpy()
    print(f"predicted_labels unique: {np.unique(predicted_labels)}")

    # Ensure target names match the expected labels
    label_indices = sorted(data.train_y.unique().tolist())
    target_names = [str(label) for label in label_indices]

    # Generate classification report
    report = classification_report(
        true_labels, 
        predicted_labels, 
        labels=label_indices,  # Specify expected class labels
        target_names=target_names
    )
    
    print("Classification Report:")
    print(report)

    return train_acc, test_acc


if __name__ == "__main__":
    # Paths
    data_path = '/home/jana7431/RGCN/dataJSON/' 
    #train_file = os.path.join(data_path, 'updated_converted_train_predictions2.json')
    #dev_file = os.path.join(data_path, 'updated_converted_dev_predictions2.json')
    #test_file = os.path.join(data_path, 'updated_converted_test_predictions2.json')
    train_file = os.path.join(data_path, 'QAupdated_train_predictions.json')
    dev_file = os.path.join(data_path, 'QAupdated_dev_predictions.json')
    test_file = os.path.join(data_path, 'QAupdated_test_predictions.json')

    # Load Data
    with open(train_file, 'r') as f:
        train_data = json.load(f)
    with open(dev_file, 'r') as f:
        dev_data = json.load(f)
    with open(test_file, 'r') as f:
        test_data = json.load(f)

    #train_n = len(train_data)
    #dev_n = len(dev_data)

    # Count the elements under "edus"
    train_n = sum(len(item["edus"]) for item in train_data if "edus" in item)
    dev_n = sum(len(item["edus"]) for item in dev_data if "edus" in item)
    test_n = sum(len(item["edus"]) for item in test_data if "edus" in item)
    print(f"train_n:{train_n}")
    print(f"dev_n:{dev_n}")
    print(f"test_n:{test_n}")

    train_idx = torch.arange(train_n+dev_n)
    test_idx = torch.arange(train_n+dev_n, train_n+dev_n+test_n)

    labels = pd.read_csv("/mnt/datastore/jana7431/RGCN/dataGEO/train/train_labels.csv")
    label_list = list(labels["labels"].values)
    label_type_map = {label: i for i, label in enumerate(set(label_list))}
    label_ids = [label_type_map[label] for label in label_list]
    labels = torch.tensor(label_ids, dtype=torch.long)
    labels_train = labels[:train_n+dev_n]
    labels_val = labels[train_n+dev_n:train_n+dev_n+test_n]
    print(f"len labels list: {len(labels)}")

    # Load Graph Data
    data = torch.load("/mnt/datastore/jana7431/RGCN/dataGEO/train/graph_data.pt")
    print(data)
    data.train_y = labels_train.to('cuda:1')
    data.test_y = labels_val.to('cuda:1')

    # Move Data to GPU
    device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")
    data = data.to(device)

    # Graph Preparation
    node_idx = torch.cat([train_idx, test_idx], dim=0)
    node_idx, edge_index, mapping, edge_mask = k_hop_subgraph(
        node_idx, 2, data.edge_index, relabel_nodes=True)

    data.num_nodes = node_idx.size(0)
    data.edge_index = edge_index.to(device)
    #tensor = torch.full((256991,), 1).to(device)
    #data.edge_type = tensor
    data.edge_type = data.edge_type[edge_mask].to(device)
    data.train_idx = mapping[:train_idx.size(0)].to(device)
    data.test_idx = mapping[train_idx.size(0):].to(device)

    num_nodes = data.num_nodes
    num_relations = len(data.edge_type.unique())
    print(len(data.edge_type))
    print(num_relations)
    #num_classes = len(data.train_y.unique())
    num_classes = len(labels.unique())
    features = data.x
    num_features = 768

    # Linear layer to reduce dimensionality
    """feature_size = 512  # Desired feature size
    reduction_layer = nn.Linear(768, feature_size).to('cuda:1')

    # Apply the linear layer
    features = reduction_layer(features)
    print(reduced_features.shape)
    num_features = feature_size"""

    print(f"num nodes: {num_nodes}")
    print(f"num relations: {num_relations}")
    print(f"num classes: {num_classes}")
    print(f"num links: {data.edge_index.size()}")


    # Model Initialization
    model = Net(features,  num_features, num_relations, num_classes).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01, weight_decay=0.0005)

    # Training Loop
    times = []
    best_test_acc = 0
    for epoch in range(1, 50):
        start = time.time()
        loss = train(model,data, optimizer)
        train_acc, test_acc = test(model,data)
        #test_acc = test()
        print(f'Epoch: {epoch:02d}, Loss: {loss:.4f}, Train: {train_acc:.4f}, Test: {test_acc:.4f}')
        #print(f'Epoch: {epoch:02d}, Loss: {loss:.4f}, Test: {test_acc:.4f}')

        if test_acc > best_test_acc:
            best_test_acc = test_acc
            torch.save(model.state_dict(), os.path.join("/mnt/datastore/jana7431/RGCN/models", "best_model_QA2.pth"))
            print(f"Model saved at epoch {epoch} with test accuracy {test_acc:.4f}")

        times.append(time.time() - start)

    print(f"Median time per epoch: {torch.tensor(times).median():.4f}s")
