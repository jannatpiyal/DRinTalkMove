import json
import pandas as pd
import torch
from transformers import BertTokenizer, BertForSequenceClassification, AdamW
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader, Dataset

# Example custom dataset
class RelationDataset(Dataset):
    def __init__(self, pairs, labels, tokenizer, max_length):
        self.pairs = pairs
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, idx):
        text_pair = self.pairs[idx]
        label = self.labels[idx]

        # Tokenize the text pairs
        encoding = self.tokenizer(
            text_pair[0],
            text_pair[1],
            max_length=self.max_length,
            padding="max_length",
            truncation=True,
            return_tensors="pt",
        )

        # Return dictionary with input IDs, attention mask, and label
        return {
            "input_ids": encoding["input_ids"].squeeze(0),
            "attention_mask": encoding["attention_mask"].squeeze(0),
            "label": torch.tensor(label, dtype=torch.long),
        }


# Data Preparation
def prepare_data(data, relation_type="Question-answer_pair"):
    positive_samples = []
    negative_samples = []

    for item in data:
        edus = item["edus"]
        relations = item["relations"]

        # Map x and y to their corresponding texts
        for relation in relations:
            x_idx = relation["x"]
            y_idx = relation["y"]
            rel_type = relation["type"]

            text_x = edus[x_idx]["text"]
            text_y = edus[y_idx]["text"]

            if rel_type == relation_type:
                positive_samples.append((text_x, text_y))
            else:
                negative_samples.append((text_x, text_y))

    # Assign labels: 1 for positive, 0 for negative
    pairs = positive_samples + negative_samples
    labels = [1] * len(positive_samples) + [0] * len(negative_samples)
    print(len(positive_samples))

    return pairs, labels

if __name__ == "__main__":

    file_names = ['molweni_dev', 'molweni_test', 'molweni_train',
                'stac_dev', 'stac_test', 'stac_train']

    data = []
    for file_name in file_names:
        with open(f'/mnt/datastore/jana7431/CorrectionModule/data/train/{file_name}.json', 'r') as f:
                json_data = json.load(f)
                data.extend(json_data)

    # Extract pairs and labels
    pairs, labels = prepare_data(data)

    # Tokenizer and model setup
    tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")
    model = BertForSequenceClassification.from_pretrained("bert-base-uncased", num_labels=2)

    # Hyperparameters
    max_length = 128
    batch_size = 16
    epochs = 3

    # Train-test split
    train_pairs, val_pairs, train_labels, val_labels = train_test_split(
        pairs, labels, test_size=0.2, random_state=42
    )

    # Prepare datasets and dataloaders
    train_dataset = RelationDataset(train_pairs, train_labels, tokenizer, max_length)
    val_dataset = RelationDataset(val_pairs, val_labels, tokenizer, max_length)

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=batch_size)

    # Optimizer and loss function
    optimizer = AdamW(model.parameters(), lr=5e-5)

    # Training loop
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    model.to(device)

    for epoch in range(epochs):
        model.train()
        total_loss = 0
        for batch in train_loader:
            optimizer.zero_grad()

            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            labels = batch["label"].to(device)

            outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
            loss = outputs.loss
            total_loss += loss.item()

            loss.backward()
            optimizer.step()

        avg_loss = total_loss / len(train_loader)
        print(f"Epoch {epoch + 1}/{epochs}, Loss: {avg_loss:.4f}")

        # Save model
        model.save_pretrained("/mnt/datastore/jana7431/CorrectionModule/models/bert_relation_classifier")
        tokenizer.save_pretrained("/mnt/datastore/jana7431/CorrectionModule/models/bert_relation_classifier")

        # Validation
        model.eval()
        correct = 0
        total = 0
        with torch.no_grad():
            for batch in val_loader:
                input_ids = batch["input_ids"].to(device)
                attention_mask = batch["attention_mask"].to(device)
                labels = batch["label"].to(device)

                outputs = model(input_ids=input_ids, attention_mask=attention_mask)
                predictions = torch.argmax(outputs.logits, dim=-1)

                correct += (predictions == labels).sum().item()
                total += labels.size(0)

        accuracy = correct / total
        print(f"Validation Accuracy: {accuracy:.4f}")
