import pandas as pd
import os
import json
import ast
import yaml
import torch
from transformers import BertTokenizer, BertModel
from torch_geometric.data import Data
os.environ["CUDA_VISIBLE_DEVICES"] = "1"

def convert_label(label):
  label = str(label).lower()
  if label in ["3 - getting ss to relate", "3 - gettingssto relate",
                               "3 - gettingsto relate", "3 - getting s to relate"]:
    label = "3 - getting students to relate"
  if label in ["2 - keeping ss together", '2', '2 - keeping everyone together']:
    label = '2 - keeping everyone together'
  if label in ['1', '1 - None', '\\', ' ']:
    label = '1 - none'
  if label in ['8', '8 - press for  accuracy','8 - pres for  accuracy', '8 - prestudents for accuracy', '8 - press for accuracy']:
    label = '8 - press for accuracy'
  if label == '4 - ressuzannang':
    label = '4 - restating'
  if label in ["2 - relating to another s", '2 - relating to another student']:
    label = "2 - relating to another student"
  if label in ['5', '5 - providing evidence/providing reasoning', '5 - providing evidence / explaining reasoning', '5 - providing evidence / reasoning', '5 - providing evidence/explaining reasoning']:
    label = '5 - providing evidence/providing reasoning'
  if label in ['3', '3 - asking for more information', '3 - asking for information']:
    label = '3 - asking for more information'
  if label in ['6 - marketing','6 - Marking']:
    label = '6 - marking'
  if label in ['4 - making a claim', '4 - making a cdavid']:
    label = '4 - making a claim'
  if label in ['9 - press for reasoning', '9 - prestudents for reasoning', '9 - pres for reasoning']:
    label = '9 - press for reasoning'
  if label in ['7\\', '7 - context']:
    label = '7 - context'
  return label


def process_json(data):
    """
    Process the JSON data to extract a list of text and convert relations into tuples with updated indices.

    :param json_file: Path to the JSON file.
    :return: A tuple (text_list, relations_list).
    """
    try:

        # Initialize the text list and relations list
        text_list = []
        relations_list = []
        label_list =[]

        for document in data:
            # Extract text from edus and build a mapping of old indices to new indices
            edu_to_text_index = {}
            for i, edu in enumerate(document.get("edus", [])):
                speaker = " "
                label = " "
                if str(edu["student_tag"]) != 'nan':
                  speaker = "S: "
                  label = edu["student_tag"]
                if str(edu["teacher_tag"]) != 'nan':
                  speaker = "T: "
                  label = edu["teacher_tag"]

                text_list.append(speaker+str(edu["text"]))
                label_list.append(convert_label(label))
                edu_to_text_index[str(i)] = len(text_list) - 1  # Map old index to new index
                relations_list.append((len(text_list) - 1 , len(text_list) - 1 , 'Self'))

            # Convert relations to tuples and update x, y indices
            for relation in document.get("relations", []):
                rel_type = relation["type"]
                old_x = int(relation["x"].split("_")[0])
                old_y = int(relation["y"].split("_")[0])

                if old_x == -1 or old_y == -1:
                    continue
                new_x = edu_to_text_index[str(old_x)]
                new_y = edu_to_text_index[str(old_y)]
                #rel_type = convert_rel_type(rel_type)
                relations_list.append((new_x, new_y, rel_type))

        return text_list, relations_list, label_list
    except Exception as e:
        print(f"Error: {e}")
        return [], []


def get_bert_embedding(sentence, tokenizer, model):
    inputs = tokenizer(sentence, return_tensors="pt", truncation=True, padding=True)
    device = torch.device("cuda:1")
    outputs = model(**inputs.to(device))
    # Use the [CLS] token embedding
    return outputs.last_hidden_state[:, 0, :].detach()

def create_graph(sentences, relations, relation_types, path, tokenizer, model, split):
    # Encode nodes using BERT embeddings
    
    node_features = torch.stack([get_bert_embedding(sentence, tokenizer, model) for sentence in sentences])
     
    # Map relations to edge indices and types
    edge_index = torch.tensor([[relation[0], relation[1]] for relation in relations], dtype=torch.long).T
    edge_type = torch.tensor([relation_types[relation[2]] for relation in relations], dtype=torch.long)
    #print(edge_type)

    # Create data object
    data = Data(
        x=node_features,  # Node features (BERT embeddings)
        edge_index=edge_index,  # Edge connections
        edge_type=edge_type,  # Edge types
    )
    data.num_nodes = node_features.size(0)
    print(data.num_nodes)
    data.num_relations = len(relation_types)
    print(data.num_relations)
    torch.save(data, os.path.join(path,"graph_data.pt"))



if __name__ == "__main__":

    # Load BERT model and tokenizer
    # initializing BERT for creating initial embeddings for the utterances
    tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
    model = BertModel.from_pretrained('bert-base-uncased')
    

    device = torch.device("cuda:1")
    #model.to(device)

    ## TRAIN DATA
    data_path = '/home/jana7431/RGCN/dataJSON/' 
    #train_file = os.path.join(data_path, 'updated_converted_train_predictions2.json')
    #dev_file = os.path.join(data_path, 'updated_converted_dev_predictions2.json')
    #test_file = os.path.join(data_path, 'updated_converted_test_predictions2.json')
    train_file = os.path.join(data_path, 'QAupdated_train_predictions.json')
    dev_file = os.path.join(data_path, 'QAupdated_dev_predictions.json')
    test_file = os.path.join(data_path, 'QAupdated_test_predictions.json')

    with open(test_file, 'r') as f:
        test_data = json.load(f)
        #test_data = test_data[:2]

    # Load the JSON data
    with open(train_file, 'r') as f:
        train_data = json.load(f)
        #train_data = train_data[:2]
    
    with open(dev_file, 'r') as f:
        dev_data = json.load(f)
        #dev_data = dev_data[:2]
   
    train_data = train_data + dev_data + test_data
        
    text_list, relations_list, label_list = process_json(train_data)

    rel_type = [tup[2] for tup in relations_list]
    rel_type_map = {rel: i for i, rel in enumerate(set(rel_type))}
    #print(rel_type_map)

    graph_data_path_train = "/mnt/datastore/jana7431/RGCN/dataGEO/train"

    split = "train"

    create_graph(text_list, relations_list, rel_type_map, graph_data_path_train, tokenizer, model, split)
    df = pd.DataFrame(label_list, columns=['labels'])
    df.to_csv(os.path.join(graph_data_path_train, 'train_labels.csv'))

    ## TEST

    
        
    """test_text_list, test_relations_list, test_label_list = process_json(test_data)

    test_rel_type = [tup[2] for tup in test_relations_list]
    test_rel_type_map = {rel: i for i, rel in enumerate(set(test_rel_type))}
    #print(rel_type_map)

    graph_data_path_test = "/mnt/datastore/jana7431/RGCN/dataGEO/test"

    split = "test"

    create_graph(test_text_list, test_relations_list, test_rel_type_map, graph_data_path_test, tokenizer, model, split)
    test_df = pd.DataFrame(test_label_list, columns=['labels'])
    test_df.to_csv(os.path.join(graph_data_path_test, 'test_labels.csv'))"""
